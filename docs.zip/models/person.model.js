const mongoose = require('mongoose');
const {toJSON, paginate} = require("./plugins");

const personSchema = mongoose.Schema(
    {
        image:{
          type:mongoose.Schema.Types.ObjectId,
          ref:"uploads.files",
        },
        name: {
            type: String,
            required: true
        },
        phoneNumber: {
            type: String,
            required: true
        },
        shopNumber: {
            type: String,
        },
        email: {
            type: String,
        },
        type: {
            type: String,
            enum: ["customer", "supplier"],
            required: true,
        },
        orders:[{
            type: mongoose.Schema.Types.ObjectId,
            ref:"Order"
        }],
        totalOverdue:{
            type: Number,
            default: 0,
            min: 0,
        }
    },
    {
        timestamps: true,
    }
)
personSchema.plugin(toJSON);
personSchema.plugin(paginate)

/**
 * Check if person exists by ObjectId
 * @param {ObjectId} id - The ObjectId of the person
 * @returns {Promise<boolean>}
 */
personSchema.statics.isPersonExistById = async function (id) {
    const person = await this.findById(id);
    return person;
};
/**
 * Check if person exists by name
 * @param {string} name - The name of the person
 * @returns {Promise<boolean>}
 */
personSchema.statics.isPersonExistByName = async function (name) {
    const person = await this.findOne({ name });
    return !!person;
};

const Person = mongoose.model('Person', personSchema);
module.exports = Person;
