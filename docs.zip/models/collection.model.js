const mongoose = require('mongoose');
const {toJSON, paginate} = require("./plugins");

const collectionSchema = mongoose.Schema(
    {
        bankName: {
            type: String,
            required: true,
        },
        image: {
            type: mongoose.Schema.Types.ObjectId,
            ref: '',
        },
        amount: {
            type: Number,
            required: true,
        },
        agentName: {
            type: String,
            required: true
        },
        agentPhoneNumber: {
            type: String,
            required: true
        },
        transactionHistory: {
            type: String,
            required: true
        },
    }
)
collectionSchema.plugin(toJSON);
collectionSchema.plugin(paginate);

const Collection = mongoose.model("Collection", collectionSchema);

module.exports = Collection;