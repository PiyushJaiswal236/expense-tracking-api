module.exports.Token = require("./token.model");
module.exports.User = require("./user.model");
module.exports.Inventory = require("./inventory.model");
module.exports.Order = require("./order.model");
module.exports.Item = require("./item.model");
module.exports.Person = require("./person.model");
module.exports.Collection = require("./collection.model");

