const {Person, User, Order} = require("../models");
const ApiError = require("../utils/ApiError");
const httpStatus = require("http-status");

//todo ask  permission to sir to  add check for shop no, phoneNo,email already taken conditions should me implemented or not
const createPerson = async (user, personBody, file) => {

    const person = await Person.create(personBody);
    user.persons.push(person.id);
    if (file !== undefined) {
        person.image = file.id;
        person.save();
    }
    if (person.totalOverdue > 0) {
        if (person.type === "customer") {
            user.pendingReceivable = user.pendingReceivable + person.totalOverdue;
        } else {
            user.pendingPayable = user.pendingPayable + person.totalOverdue;
        }
    }
    user.save();
    return person;
}

const queryPersons = async (userId, filter, options) => {
    const persons = await User.findById(userId).select("persons").populate({
        path: "persons",
        match: filter,
        options: {
            sort: options.sortBy,
            limit: options.limit ? parseInt(options.limit, 10) : 10,
            skip: options.page ? (parseInt(options.page, 10) - 1) * options.limit : 0
        }
    });
    return persons;
};
// todo check the user.persons.contains(personId)
const updatePerson = async (user,personId, updatedBody) => {
    const person = await Person.findById(personId);
    if (!person) {
        throw new ApiError(httpStatus.NOT_FOUND, `Person with id ${personId} not found`);
    }
    if(!user.persons.includes(personId)){
        throw new ApiError(httpStatus.FORBIDDEN, "Not allowed to update this persons");
    }
    const updatePerson = await Person.findByIdAndUpdate(personId, updatedBody);
    if (!updatePerson) {
        throw new ApiError(httpStatus.NOT_FOUND, "No such person with ID ");
    }
    return updatePerson;
}

const deletePerson = async (user, personId) => {
    const person = await Person.findById(personId);
    if (!person) {
        throw new ApiError(httpStatus.NOT_FOUND, `Person with id ${personId} not found`);
    }
    if(!user.persons.includes(personId)){
        throw new ApiError(httpStatus.FORBIDDEN, "Not allowed to delete this persons");
    }
    if (person.totalOverdue > 0) {
        if (person.type === "customer") {
            user.pendingReceivable = user.pendingReceivable - person.totalOverdue;
        } else {
            user.pendingPayable = user.pendingPayable - person.totalOverdue;
        }
    }
    // await Order.deleteMany({personId: personId});
    user.persons.pull(personId);
    user.save();
    return Person.findByIdAndDelete(personId, {new: true});
}

module.exports = {
    createPerson,
    queryPersons,
    updatePerson,
    deletePerson
}