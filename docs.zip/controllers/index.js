module.exports.authController = require("./auth.controller");
module.exports.userController = require("./user.controller");
module.exports.inventoryController = require("./inventory.controller");
module.exports.ordersController = require("./orders.controller");
module.exports.personController = require("./person.controller");