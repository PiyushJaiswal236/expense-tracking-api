const Joi = require("joi");
const {objectId} = require("./custom.validation");

const getPersons = {
    
    query: Joi.object().keys({
        itemIds: Joi.string(),
        period:Joi.string(),
        amount: Joi.string(),
        type: Joi.string(),
        sortBy: Joi.string(),
        limit: Joi.number().integer(),
        page: Joi.number().integer(),
    }),
};
const createPerson = {
    body: Joi.object().keys({
        name: Joi.string().required(),
        phoneNumber: Joi.string().required(),
        shopNo: Joi.string(),
        email: Joi.string().email(),
        totalOverdue: Joi.number().integer().min(0),
        type: Joi.string().valid("customer", "supplier").required(),
        orders: Joi.array().items(Joi.custom(objectId)),
    })
}
const updatePerson = {
    params: Joi.object().keys({
        personId: Joi.custom(objectId)
    })
}
const deletePerson = {
    params: Joi.object().keys({
        personId: Joi.custom(objectId)
    })
}

module.exports = {
    getPersons,
    createPerson,
    updatePerson,
    deletePerson,
}
