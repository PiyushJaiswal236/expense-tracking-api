const Joi = require("joi");
const {objectId} = require("./custom.validation");

const addItem = {
    body: Joi.object().keys({
        itemData: Joi.object().keys({
            name: Joi.string().required(),
            category: Joi.string().valid("Fresh Vegetables", "Fresh Fruits", "Seasonal",'Leafy & Herbs',"Frozen Veg").required(),
            description: Joi.string(),
        })
    })
}
const updateItem = {
    params: Joi.object().keys({
        itemId: Joi.custom(objectId),
    }),
    body: Joi.object().keys({
        itemData: Joi.object().keys({
            name: Joi.string(),
            category: Joi.string().valid("Fresh Vegetables", "Fresh Fruits", "Seasonal",'Leafy & Herbs',"Frozen Veg"),
            description: Joi.string(),
        })
    })
}
const deleteItem ={
    params: Joi.object().keys({
        itemId: Joi.custom(objectId),
    })
}
module.exports = {
    addItem,
    updateItem,
    deleteItem
};