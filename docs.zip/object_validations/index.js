module.exports.authValidation = require("./auth.validation");
module.exports.userValidation = require("./user.validation");
module.exports.inventoryValidation = require("./inventory.validation");
module.exports.personValidation = require("./person.validation");
module.exports.orderValidation = require("./order.validation");
